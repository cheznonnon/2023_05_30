// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
n_win_txtbox_caret_reset( n_win_txtbox *p, n_posix_bool show_onoff )
{
//return;

	if ( show_onoff )
	{
		p->caret_blend   = 1.0;
		p->caret_fade_in = n_posix_true;
	} else {
		p->caret_blend   = 0.0;
		p->caret_fade_in = n_posix_false;
	}


	return;
}

void
n_win_txtbox_caret_onoff( n_win_txtbox *p, n_posix_bool onoff )
{

	// [x] : n_win_txtbox_caret_reset() interferes N_WIN_TXTBOX_OPTION_CARET_BLINK_OFF

	if ( p->style_option & N_WIN_TXTBOX_OPTION_CARET_BLINK_OFF )
	{

		if ( onoff )
		{
			//n_win_txtbox_caret_reset( p, n_posix_true );
			n_win_timer_init( p->hwnd, p->caret_timer, 10 );
		} else {
			n_win_timer_exit( p->hwnd, p->caret_timer );
		}

	} else {

		if ( onoff )
		{
			//n_win_txtbox_caret_reset( p, n_posix_true );
			n_win_timer_init( p->hwnd, p->caret_timer, 10 );
		} else {
			n_win_timer_exit( p->hwnd, p->caret_timer );
		}

	}


	return;
}



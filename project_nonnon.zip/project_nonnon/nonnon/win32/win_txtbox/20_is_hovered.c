// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




n_posix_bool
n_win_txtbox_is_hovered( n_win_txtbox *p )
{
//return n_posix_false;

	if ( p == NULL ) { return n_posix_false; }

	if ( n_posix_false == IsWindow       ( p->hwnd ) ) { return n_posix_false; }
	if ( n_posix_false == IsWindowVisible( p->hwnd ) ) { return n_posix_false; }


	if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
	{
		n_type_gfx cursor_x, cursor_y;
		n_win_cursor_position_relative( n_win_hwnd_toplevel( p->hwnd ), &cursor_x, &cursor_y );

		extern n_posix_bool n_win_txtbox_input_resizer_onoff( n_win_txtbox*, n_type_gfx, n_type_gfx );
		if ( n_win_txtbox_input_resizer_onoff( p, cursor_x, cursor_y ) ) { return n_posix_false; }
	}


	n_posix_bool is_hovered;

	p->hover_cch_x = 0;

	{

		n_type_gfx sx,sy; n_win_size( p->hwnd, &sx, &sy );

		if ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL ) { sy -= GetSystemMetrics( SM_CYHSCROLL ); }
		if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL ) { sx -= GetSystemMetrics( SM_CXVSCROLL ); }

		if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
		{
			// [!] : for usability : see draw_singleline() edit_on_typing()
			//sx -= p->pad_pxl_sx * 2;
		} else {
			sx -= p->pad_pxl_sx * 2;
			sy -= p->pad_pxl_sy * 2;
		}

		n_type_gfx x = p->shadow_l;

		sx -= p->shadow_l + p->shadow_r;

		is_hovered = n_win_is_hovered_offset( p->hwnd, x,0,sx,sy );

	}


	// [!] : fail-safe

	if ( p->cell_pxl_sy <= 0 ) { return is_hovered; }


	// [!] : N_WIN_TXTBOX_OPTION_LISTBOX_KEEPSEL : out-of-bound area is acceptable for usability

	n_type_gfx x,y; n_win_cursor_position_relative( p->hwnd, &x, &y );

	if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
	{

		if ( p->is_captured == n_posix_false )
		{
			p->hover_cch_y = 0;

			extern n_posix_bool n_win_txtbox_smallbutton_direct_is_hovered( n_win_txtbox *p );

//n_win_txtbox_hwndprintf_literal( p, " %d ", n_win_txtbox_smallbutton_direct_is_hovered( p ) );
			if ( n_win_txtbox_smallbutton_direct_is_hovered( p ) ) { return n_posix_false; }
		}

	} else {

		// [!] : -1 means "all lines"

		n_type_gfx v = ( p->scroll_pxl_tabbed_y % p->cell_pxl_sy );
		n_type_gfx o = ( y - p->border_pxl_sy - p->pad_pxl_sy + v ) / p->cell_pxl_sy;

		if ( o <= -1 )
		{
			p->hover_cch_y = n_posix_max_n_type_int( 0, p->hover_cch_y + o );
			if ( p->scroll_pxl_tabbed_y == 0 )
			{
				p->hover_under = o;
			} else {
				p->hover_under = 0;
			}
		} else {
			p->hover_under = 0;
			p->hover_cch_y = ( p->scroll_pxl_tabbed_y / p->cell_pxl_sy ) + o;
		}
//n_win_txtbox_hwndprintf_literal( p, " %d : %d ", o, p->hover_cch_y );


		// [!] : when a tail of a screen is clicked
/*
//n_win_txtbox_hwndprintf_literal( p, " %d : %d ", o, v );

		if ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX )
		{
			if ( n_win_is_input( VK_LBUTTON ) )
			{

				n_type_gfx count = p->canvas_pxl_sy / p->cell_pxl_sy;
n_win_txtbox_hwndprintf_literal( p, " %d %d ", o, count );

				n_posix_bool hscr_is_hovered = n_win_is_hovered( p->hscr.hwnd );
				n_posix_bool vscr_onoff      = ( ( p->page_pxl_tabbed_sy / p->cell_pxl_sy ) < p->txt.sy );
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", hscr_is_hovered, vscr_onoff );

				if (
					( vscr_onoff )
					&&
					( hscr_is_hovered == n_posix_false )
					&&
					( o >= count )
				)
				{
					return n_posix_false;
				}

			}
		}
*/
	}


	if ( n_posix_false == ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX ) ) { return is_hovered; }
//return is_hovered;

//n_win_txtbox_hwndprintf_literal( p, " %d ", p->hover_cch_y );
//n_win_txtbox_hwndprintf_literal( p, " %d ", ( p->hover_cch_y >= p->txt.sy ) );

	// [!] : Notepad compatible behavior

	if ( p->hover_cch_y <          0 ) { return is_hovered; }
	if ( p->hover_cch_y >= p->txt.sy ) { p->hover_cch_y = p->txt.sy - 1; }


	n_type_int nc_sx = p->pad_pxl_sx;
	n_type_int nc_sy = p->pad_pxl_sy;

	if ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX )
	{
		if ( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_HCENTER ) { nc_sx += n_win_txtbox_horizontal_centering( p ); }
		if ( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_LINENUM ) { nc_sx += p->number_pxl_sx + p->number_pad_pxl_sx; }
	}

	// [!] : for usability

	p->is_hovered_linenum = n_posix_false;

	if ( is_hovered )
	{
		n_type_int pad_fx = 0;
		n_type_int pad_tx = nc_sx;

		if ( ( x >= pad_fx )&&( x <= pad_tx ) )
		{
//n_posix_debug_literal( " ! " );
			p->hover_cch_x = 0;

			if ( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_LINENUM )
			{
				p->is_hovered_linenum = n_posix_true;
			}

			return n_posix_true;
		}

	}


	// [Needed] : for press'n'run

	if ( x < nc_sx ) { return n_posix_false; }


	HDC hdc = GetDC( p->hwnd );


	HFONT hf = SelectObject( hdc, n_win_font_get( p->hwnd ) );


	n_posix_char *text = n_win_txtbox_txt_get( p, p->hover_cch_y );


	SIZE       size = { 0,0 };
	n_type_int cch  = 0;
	n_type_int tab  = 0;

	n_type_int osx    = p->scroll_pxl_tabbed_x;
	n_type_int draw_x = nc_sx - osx;
	n_type_int text_x = 0;
	POINT cursor = { x, (int) ( nc_sy + ( y / p->cell_pxl_sy * p->cell_pxl_sy ) ) };
	n_posix_loop
	{//break;

		n_posix_char *character = n_win_txtbox_character( p, hdc, text, text_x, &size, &cch, &tab );


		n_type_int inc = n_string_doublebyte_increment( text[ text_x ] );
		if (
			( n_unicode_surrogatepair_is_hi( character[ 0 ] ) )
			&&
			( n_unicode_surrogatepair_is_lo( character[ 1 ] ) )
		)
		{
			inc = 2;
		}

		RECT rect; n_win_rect_set( &rect, (int) draw_x, (int) cursor.y, (int) size.cx, (int) p->cell_pxl_sy );

		if ( n_string_is_empty( character ) )
		{

			p->hover_cch_x = text_x;

			break;

		} else
		if ( PtInRect( &rect, cursor ) )
		{

			n_type_int half_sx = ( size.cx / 2 );

			n_win_rect_set( &rect, (int) ( draw_x + half_sx ), (int) cursor.y, (int) half_sx, (int) p->cell_pxl_sy );

			if ( PtInRect( &rect, cursor ) ) { text_x += (n_type_gfx) inc; }


			p->hover_cch_x = text_x;


			break;

		}

		draw_x += size.cx;
		text_x += (n_type_gfx) inc;

	}


	SelectObject( hdc, hf );

	ReleaseDC( p->hwnd, hdc );


	return is_hovered;
}



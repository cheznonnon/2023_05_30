// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_WIN
#define _H_NONNON_WIN32_WIN




#include "../neutral/posix.c"




#include <math.h>




// component

#include "./win/_debug.c"
#include "./win/animatewindow.c"
#include "./win/bitmap.c"
#include "./win/color.c"
#include "./win/commandline.c"
#include "./win/control.c"
#include "./win/cornercolor.c"
#include "./win/cursor.c"
#include "./win/darkmode.c"
#include "./win/dwm.c"
#include "./win/flickerfree.c"
#include "./win/fluent_ui.c"
#include "./win/font.c"
#include "./win/grab_n_drag.c"
#include "./win/gui.c"
#include "./win/icon.c"
#include "./win/ime.c"
#include "./win/input.c"
#include "./win/message.c"
#include "./win/move.c"
#include "./win/rect.c"
#include "./win/set.c"
#include "./win/stdfont.c"
#include "./win/stdsize.c"
#include "./win/style.c"
#include "./win/timer.c"




#define n_win_redraw(     h, b ) n_win_message_send( h, WM_SETREDRAW, b, 0 )
#define n_win_redraw_on(  h    ) n_win_redraw( h, n_posix_true  )
#define n_win_redraw_off( h    ) n_win_redraw( h, n_posix_false )




void
n_win_init_background( HWND hwnd )
{

	// [!] : this is not "COLOR_BACKGROUND"

	// [MSDN] : don't use GetSysColorBrush( COLOR_BTNFACE );

	HBRUSH  hb;

	if ( n_win_darkmode_onoff )
	{
		hb = n_win_darkmode_brush_bg( COLOR_BTNFACE );
	} else {
		hb = (HBRUSH) ( COLOR_BTNFACE + 1 );
	}


#ifdef _WIN64
	SetClassLongPtr( hwnd, GCLP_HBRBACKGROUND, (LONG_PTR) hb );
#else  // #ifdef _WIN64
	SetClassLong   ( hwnd, GCL_HBRBACKGROUND , (LONG    ) hb );
#endif // #ifdef _WIN64


	return;
}

#define n_win_init_literal( h,t,i,c ) n_win_init( h, n_posix_literal( t ), n_posix_literal( i ), n_posix_literal( c ) )

void
n_win_init
(
	              HWND  hwnd,
	const n_posix_char *title,
	const n_posix_char *rc_ico,
	const n_posix_char *rc_cur
)
{

	// [!] : if loading from resources, HINSTANCE is needed

	const HINSTANCE hinst = GetModuleHandle( NULL );


	HICON   hi;
	HCURSOR hc;


	SetWindowText( hwnd, title );


	hi = LoadIcon( hinst, rc_ico );


	if ( (DWORD) rc_cur <= SHRT_MAX )
	{

		// [!] : IDC_*

		hc = LoadCursor( NULL, rc_cur );

	} else
	if ( n_string_is_empty( rc_cur ) )
	{

		hc = LoadCursor( NULL, IDC_ARROW );

	} else {

		// [x] : Win9x : cursor flickers without LR_MONOCHROME

		hc = LoadImage
		(
			hinst,
			rc_cur,
			IMAGE_CURSOR,
			0,0, LR_VGACOLOR | LR_MONOCHROME
		);

	}


	n_win_init_background( hwnd );


#ifdef _WIN64
	SetClassLongPtr( hwnd, GCLP_HICON  , (LONG_PTR) hi );
	SetClassLongPtr( hwnd, GCLP_HCURSOR, (LONG_PTR) hc );
#else  // #ifdef _WIN64
	SetClassLong   ( hwnd, GCL_HICON   , (LONG    ) hi );
	SetClassLong   ( hwnd, GCL_HCURSOR , (LONG    ) hc );
#endif // #ifdef _WIN64


	return;
}

void
n_win_topmost( HWND hwnd, n_posix_bool onoff )
{

	HWND h;


	if ( onoff == n_posix_false )
	{
		h = HWND_NOTOPMOST;
	} else {
		h = HWND_TOPMOST;
	}

	SetWindowPos( hwnd, h, 0,0,0,0, SWP_NOSIZE | SWP_NOMOVE | SWP_NOACTIVATE );


	return;
}

void
n_win_xmouse( HWND hwnd, UINT msg )
{

	switch( msg ) {

	case WM_MOUSEMOVE   :
	case WM_NCMOUSEMOVE :

		if ( hwnd == GetActiveWindow() ) { break; }

		SetActiveWindow( hwnd );

	break;

	} // switch


	return;
}

n_posix_bool
n_win_is_hovered_offset( HWND hwnd, n_type_gfx x, n_type_gfx y, n_type_gfx sx, n_type_gfx sy )
{

	POINT p; n_win_cursor_position_relative( hwnd, &p.x, &p.y );
	RECT  r; n_win_rect_set( &r, x,y,sx,sy );


	return PtInRect( &r, p );
}

n_posix_bool
n_win_is_hovered( HWND hwnd )
{

	if ( n_posix_false == IsWindowVisible( hwnd ) ) { return n_posix_false; }


	POINT p; GetCursorPos( &p );
	RECT  r; GetWindowRect( hwnd, &r );


	return PtInRect( &r, p );
}

void
n_win_size_client( HWND hwnd, n_type_gfx *sx, n_type_gfx *sy )
{

	// [!] : frame border is excluded

	RECT r; GetClientRect( hwnd, &r );
	n_win_rect_expand_size( &r, NULL, NULL, sx, sy );


	return;
}

void
n_win_sysmenu_disable( HWND hwnd, n_posix_bool m0, n_posix_bool m1, n_posix_bool m2, n_posix_bool m3, n_posix_bool m4, n_posix_bool m5, n_posix_bool m6 )
{

	HMENU hmenu = GetSystemMenu( hwnd, n_posix_false );


	if ( m0 ) { DeleteMenu( hmenu, SC_RESTORE,   MF_BYCOMMAND ); }
	if ( m1 ) { DeleteMenu( hmenu, SC_MOVE,      MF_BYCOMMAND ); }
	if ( m2 ) { DeleteMenu( hmenu, SC_SIZE,      MF_BYCOMMAND ); }
	if ( m3 ) { DeleteMenu( hmenu, SC_MINIMIZE,  MF_BYCOMMAND ); }
	if ( m4 ) { DeleteMenu( hmenu, SC_MAXIMIZE,  MF_BYCOMMAND ); }
	if ( m5 ) { DeleteMenu( hmenu, 0,            MF_BYCOMMAND ); }
	if ( m6 ) { DeleteMenu( hmenu, SC_CLOSE,     MF_BYCOMMAND ); }


	DrawMenuBar( hwnd );


	return;
}

void
n_win_tabletpc_disable( HWND hwnd )
{

	// [!] : Tpcshrd.h

	const n_posix_char *n_MICROSOFT_TABLETPENSERVICE_PROPERTY = n_posix_literal( "MicrosoftTabletPenServiceProperty" );

	const DWORD n_TABLET_ENABLE_FLICKSONCONTEXT   = 0x00020000;
	const DWORD n_TABLET_ENABLE_FLICKLEARNINGMODE = 0x00040000;
	const DWORD n_TABLET_ENABLE_MULTITOUCHDATA    = 0x01000000;

	DWORD enable = 
		n_TABLET_ENABLE_FLICKSONCONTEXT |
		n_TABLET_ENABLE_FLICKLEARNINGMODE |
		n_TABLET_ENABLE_MULTITOUCHDATA;

	DWORD disable = 0xffffffff & ~enable;


	ATOM atom = GlobalAddAtom( n_MICROSOFT_TABLETPENSERVICE_PROPERTY );

   	SetProp( hwnd, n_MICROSOFT_TABLETPENSERVICE_PROPERTY, (HANDLE) disable );

	GlobalDeleteAtom( atom );


	return;
}

void
n_win_ghostwindow_disable( void )
{

	HMODULE hmod;
	FARPROC func;


	hmod = LoadLibrary( n_posix_literal( "user32.dll" ) );
	if ( hmod == NULL ) { return; }

	func = GetProcAddress( hmod, "DisableProcessWindowsGhosting" );
	if ( func != NULL ) { func(); }

	FreeLibrary( hmod );


	return;
}

void
n_win_dpi_autoscale_disable( void )
{

	typedef enum {

		n_PROCESS_DPI_UNAWARE           = 0,
		n_PROCESS_SYSTEM_DPI_AWARE      = 1,
		n_PROCESS_PER_MONITOR_DPI_AWARE = 2

	} n_PROCESS_DPI_AWARENESS;

	HMODULE hmod = LoadLibrary( n_posix_literal( "Shcore.dll" ) );
	FARPROC func = GetProcAddress( hmod, "SetProcessDpiAwareness" );
	if ( func )
	{
		func( n_PROCESS_PER_MONITOR_DPI_AWARE );
	} else {
		hmod = LoadLibrary( n_posix_literal( "user32.dll" ) );
		func = GetProcAddress( hmod, "SetProcessDPIAware" );

		if ( func ) { func(); }
	}

	FreeLibrary( hmod );


	return;
}

void
n_win_on_erasebkgnd( HWND hgui, HDC hdc )
{

	// [ Mechanism ]
	//
	//	use at WM_ERASEBKGND with "return TRUE;"
	//	don't use with uxtheme'ed controls


	n_type_gfx fx,fy,tx,ty;

	n_win_position( hgui, &fx, &fy );
	n_win_size    ( hgui, &tx, &ty ); tx += fx; ty += fy;

	ExcludeClipRect( hdc, fx,fy,tx,ty );


	return;
}

void
n_win_on_mousemove( HWND hwnd )
{

	// [ Mechanism ]
	//
	//	call this module in WM_MOUSEMOVE
	//	then WM_MOUSEHOVER and WM_MOUSELEAVE are sent


	HMODULE hmod = LoadLibrary( n_posix_literal( "user32.dll" ) );
	if ( hmod == NULL ) { return; }

	FARPROC TrackMouseEvent = GetProcAddress( hmod, "TrackMouseEvent" );

	// [!] : Win95 + IE3 or later

	if ( TrackMouseEvent == NULL )
	{
		FreeLibrary( hmod );
		hmod = LoadLibrary( n_posix_literal( "comctl32.dll" ) );
		TrackMouseEvent = GetProcAddress( hmod, "_TrackMouseEvent" );
	}


	if ( TrackMouseEvent != NULL )
	{

		// [MSDN] : use tme.dwHoverTime = HOVER_DEFAULT;
		//
		//	but WinXP/Vista/7 always use 1


		TRACKMOUSEEVENT tme;


		tme.cbSize      = sizeof( TRACKMOUSEEVENT );
		tme.dwFlags     = TME_HOVER | TME_LEAVE;
		tme.hwndTrack   = hwnd;
		tme.dwHoverTime = 1;//HOVER_DEFAULT;


		TrackMouseEvent( &tme );

	}

	FreeLibrary( hmod );


	return;
}

#define n_win_on_mousemove_fast_init( hwnd ) n_win_on_mousemove_fast( hwnd, 0 )
#define n_win_on_mousemove_fast_loop( hwnd ) n_win_on_mousemove_fast( hwnd, 1 )
#define n_win_on_mousemove_fast_exit( hwnd ) n_win_on_mousemove_fast( hwnd, 2 )

void
n_win_on_mousemove_fast( HWND hwnd, int phase )
{

	// [ Mechanism ]
	//
	//	call this module in WM_MOUSEMOVE
	//	then WM_MOUSEHOVER and WM_MOUSELEAVE are sent


	static HMODULE         hmod = NULL;
	static FARPROC         func = NULL;
	static TRACKMOUSEEVENT tme;

	if ( phase == 0 )
	{

		hmod = LoadLibrary( n_posix_literal( "user32.dll" ) );
		if ( hmod == NULL ) { return; }

		func = GetProcAddress( hmod, "TrackMouseEvent" );

		// [!] : Win95 + IE3 or later

		if ( func == NULL )
		{
			FreeLibrary( hmod );
			hmod = LoadLibrary( n_posix_literal( "comctl32.dll" ) );
			func = GetProcAddress( hmod, "_TrackMouseEvent" );
		}

		if ( func != NULL )
		{

			// [MSDN] : use tme.dwHoverTime = HOVER_DEFAULT;
			//
			//	but WinXP/Vista/7 always use 1

			tme.cbSize      = sizeof( TRACKMOUSEEVENT );
			tme.dwFlags     = TME_HOVER | TME_LEAVE;
			tme.hwndTrack   = hwnd;
			tme.dwHoverTime = 1;//HOVER_DEFAULT;

		}

	} else
	if ( phase == 1 )
	{

		if ( func != NULL ) { func( &tme ); }

	} else
	if ( phase == 2 )
	{

		FreeLibrary( hmod );

	}


	return;
}

void
n_win_mousewheel_redirector( UINT msg_mousewheel, MSG *msg )
{

	if ( msg == NULL ) { return; }

	if ( msg_mousewheel ==      WM_NULL ) { return; }
	if ( msg_mousewheel != msg->message ) { return; }

/*
n_win_hwndprintf_literal
(
	n_win_hwnd_toplevel( msg->hwnd ),
	"wParam Lo %d Hi %d : lParam X %d Y %d",
	LOWORD( msg->wParam ), HIWORD( msg->wParam ),
	LOWORD( msg->lParam ), HIWORD( msg->lParam )
);
*/

	int delta = LOWORD( msg->wParam );
	int state = 0;

	if ( n_win_is_input( VK_CONTROL  ) ) { state |= MK_CONTROL ; }
	if ( n_win_is_input( VK_LBUTTON  ) ) { state |= MK_LBUTTON ; }
	if ( n_win_is_input( VK_MBUTTON  ) ) { state |= MK_MBUTTON ; }
	if ( n_win_is_input( VK_RBUTTON  ) ) { state |= MK_RBUTTON ; }
	if ( n_win_is_input( VK_SHIFT    ) ) { state |= MK_SHIFT   ; }
	if ( n_win_is_input( VK_XBUTTON1 ) ) { state |= MK_XBUTTON1; }
	if ( n_win_is_input( VK_XBUTTON2 ) ) { state |= MK_XBUTTON2; }

	msg->message = WM_MOUSEWHEEL;
	msg->wParam  = n_win_param_hilo( delta, state );


	return;
}

void
n_win_msgloop_shared_process( HWND hwnd, MSG *msg, UINT msg_mousewheel )
{

	if ( msg->hwnd == hwnd )
	{
/*
		if ( msg->message == WM_CREATE )
		{
//n_posix_debug_literal( "WM_CREATE" );
			// [!] : never come
		} else
		if ( msg->message == WM_CLOSE )
		{
//n_posix_debug_literal( "WM_CLOSE" );
			// [!] : never come
		}// else
*/

	} else {

		if ( msg->message == WM_DROPFILES )
		{

			// [!] : for Windows95 without IE4

			msg->hwnd = hwnd;

		} else
		if (
			( msg->message >= WM_KEYFIRST )
			&&
			( msg->message <= WM_KEYLAST  )
		)
		{

			// [!] : keyboard input event redirector

			n_win_message_send( hwnd, msg->message, msg->wParam, msg->lParam );

		}// else

	}


	n_win_mousewheel_redirector( msg_mousewheel, msg );


	n_win_mbutton2centering_proc( msg->hwnd, msg->message, msg->wParam, msg->lParam );


	TranslateMessage( msg );
	DispatchMessage ( msg );


	return;
}

MSG
n_win_msgloop( HWND hwnd )
{

	UINT msg_mousewheel = RegisterWindowMessage( n_posix_literal( "MSWHEEL_ROLLMSG" ) );
//if ( msg_mousewheel == WM_NULL ) { n_posix_debug_literal( " WM_NULL " ); }


	MSG msg; ZeroMemory( &msg, sizeof( MSG ) );
	while( 1 <= GetMessage( &msg, NULL, 0, 0 ) )
	{

		n_win_msgloop_shared_process( hwnd, &msg, msg_mousewheel );

	}


	return msg;
}

#define n_win_main_literal( a, b ) n_win_main( n_posix_literal( a ), b )

int
n_win_main( const n_posix_char *mutex, void *wndproc )
{

	HANDLE hmutex = NULL;

	if ( mutex != NULL )
	{
		hmutex = n_win_mutex_init( hmutex, mutex );
		if ( hmutex == NULL ) { return 0; }
	}


	// [!] : WinXP or later : ghost window feature is buggy
	//
	//	XP    : a parent folder or an EXE file will be locked
	//	Vista : removable drive cannot be unplugged
	//	7     : an old EXE file cache is used and keep on crashing

	n_win_ghostwindow_disable();


	n_win_dpi_autoscale_disable();


	n_win_cornercolor_init();


	HWND hwnd = NULL; n_win_gui( NULL, N_WIN_GUI_WINDOW, wndproc, &hwnd );


	WPARAM wparam = n_win_msgloop( hwnd ).wParam;


	if ( mutex != NULL )
	{
		hmutex = n_win_mutex_exit( hmutex );
	}


	n_memory_debug_refcount();


	return (int) wparam;
}


#endif // _H_NONNON_WIN32_WIN


// Project Nonnon
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Template File


// [!] : Usage
//
//	1 : replace your NSView (Custom View) to NonnonGame
//	2 : IB : right pane : "Custom Class", "Class", set "NonnonGame"
//	3 : modify behavior


// [!] : trouble shooter
//
//	[ drawRect is not called at redraw ]
//
//		a : call [_n_game display];
//		b : see your @property and connect(DnD) to UI on the Xib canvas
//		c : layer may cause




#ifndef _H_NONNON_MAC_NONNON_GAME
#define _H_NONNON_MAC_NONNON_GAME




#import <Cocoa/Cocoa.h>
//#import <AVFoundation/AVFoundation.h>




#include "../../nonnon/mac/_mac.c"
#include "../../nonnon/mac/image.c"
#include "../../nonnon/mac/sound.c"
#include "../../nonnon/mac/window.c"




@interface NonnonGame : NSView
//@interface NonnonGame : NSView <AVAudioPlayerDelegate>
@end




#include "lm2.c"




@interface NonnonGame ()

@end


@implementation NonnonGame {

	n_lm2 lm2;

}


- (instancetype)initWithCoder:(NSCoder *)coder
{
//NSLog( @"initWithCoder" );

	self = [super initWithCoder:coder];
	if ( self )
	{
		n_lm2_zero( &lm2 );
		n_lm2_init( &lm2 );
//NSLog( @"%d %d", lm2.sx, lm2.sy );

		lm2.self = self;

		n_mac_timer_init( self, @selector( n_timer_method ), 1 );
	}


	return self;
}


- (void) n_mac_game_canvas_resize:(NSWindow*)window width:(n_type_gfx)sx height:(n_type_gfx)sy
{

	if ( sx == -1 ) { sx = lm2.csx; }
	if ( sy == -1 ) { sy = lm2.csy; }

	n_bmp_new( &lm2.canvas, sx, sy );
	n_bmp_flush( &lm2.canvas, lm2.color );

	NSSize size = NSMakeSize( sx,sy );

	[window setContentMinSize:size];
	[window setContentMaxSize:size];

	NSRect rect = NSMakeRect( 0,0,sx,sy );
	[self setFrame:rect];

	[window setContentSize:size];

	lm2.refresh = TRUE;

	[window display];

}

/*
- (BOOL) isFlipped
{
	return YES;
}
*/

- (void) n_timer_method
{

//NSLog( @"%f", CACurrentMediaTime() );

	static u32 timer = 0;
	if ( n_game_timer( &timer, 12 ) )
	{
		n_lm2_loop( &lm2 );
	}


	if ( lm2.refresh )
	{
		lm2.refresh = FALSE;

		[self display];
	}

}


- (void)drawRect:(NSRect)rect
{
//NSLog( @"drawRect" );

	n_type_gfx sx = N_BMP_SX( &lm2.canvas );
	n_type_gfx sy = N_BMP_SY( &lm2.canvas );
//NSLog( @"drawRect : %d %d", sx,sy );

	rect = NSMakeRect( 0,0,sx,sy );

	n_mac_image_nbmp_direct_draw( &lm2.canvas, &rect, n_posix_true );

}




- (void) NonnonLM2HighScoreReset
{

	lm2.hiscore = 0;

}

- (void) NonnonLM2HighScoreWrite
{

	n_lm2_settings_write( &lm2 );

}




- (BOOL)acceptsFirstResponder
{
//NSLog(@"acceptsFirstResponder");
	return YES;
}

- (BOOL)becomeFirstResponder
{
//NSLog(@"becomeFirstResponder");

        return YES;
}

- (void) keyDown : (NSEvent*) event
{
//NSLog( @"Key Code = %d : Chars %@", event.keyCode, event.characters );


	if ( lm2.title_screen_onoff )
	{
		n_lm2_sound( &lm2, N_LM2_START_INDEX );

		n_bmp_new( &lm2.title_screen_transition_bmp_old, lm2.csx, lm2.csy );
		n_bmp_new( &lm2.title_screen_transition_bmp_new, lm2.csx, lm2.csy );

		n_bmp_flush_fastcopy( &lm2.canvas, &lm2.title_screen_transition_bmp_old );

		lm2.title_screen_onoff = n_posix_false;

		n_lm2_reset( &lm2 );
		n_bmp_flush_fastcopy( &lm2.bmp[ N_LM2_BMPBG_INDEX ], &lm2.canvas );

		lm2.title_screen_stop_movement = n_posix_true;
		n_lm2_loop ( &lm2 );
		lm2.title_screen_stop_movement = n_posix_false;

		n_bmp_flush_fastcopy( &lm2.canvas, &lm2.title_screen_transition_bmp_new );

		lm2.title_screen_transition_onoff = n_posix_true;

		return;
	}


	switch( event.keyCode ) {

	case N_MAC_KEYCODE_ARROW_LEFT:

		lm2.input |= N_LM2_INPUT_L;
//NSLog( @"N_MAC_KEYCODE_ARROW_LEFT : %d", lm2.input );

		n_lm2_input( &lm2 );

	break;

	case N_MAC_KEYCODE_ARROW_RIGHT:

		lm2.input |= N_LM2_INPUT_R;
//NSLog( @"N_MAC_KEYCODE_ARROW_RIGHT : %d", lm2.input );

		n_lm2_input( &lm2 );

	break;

	case N_MAC_KEYCODE_SPACE:

		lm2.input |= N_LM2_INPUT_FIRE;

		n_lm2_input( &lm2 );

	break;

	case N_MAC_KEYCODE_F1:

		lm2.input |= N_LM2_INPUT_F1;

	break;

	case N_MAC_KEYCODE_F2:

		lm2.input |= N_LM2_INPUT_F2;

	break;

	case N_MAC_KEYCODE_F3:

		lm2.input |= N_LM2_INPUT_F3;

	break;

	} // switch

}

- (void) keyUp : (NSEvent*) event
{
//return;

	switch( event.keyCode ) {

	case N_MAC_KEYCODE_ARROW_LEFT:

		lm2.input &= ~N_LM2_INPUT_L;

		n_lm2_input( &lm2 );

	break;

	case N_MAC_KEYCODE_ARROW_RIGHT:

		lm2.input &= ~N_LM2_INPUT_R;

		n_lm2_input( &lm2 );

	break;

	case N_MAC_KEYCODE_SPACE:

		lm2.input &= ~N_LM2_INPUT_FIRE;

		n_lm2_input( &lm2 );

	break;

	case N_MAC_KEYCODE_F1:

		lm2.input &= ~N_LM2_INPUT_F1;

	break;

	case N_MAC_KEYCODE_F2:

		lm2.input &= ~N_LM2_INPUT_F2;

	break;

	case N_MAC_KEYCODE_F3:

		lm2.input &= ~N_LM2_INPUT_F3;

	break;

	} // switch

}




- (void) mouseDown:(NSEvent*) theEvent
{
//NSLog(@"mouseDown");

	if ( [theEvent clickCount] >= 2 )
	{
		n_mac_window_centering( self.window );
	} else {
		[self.window performWindowDragWithEvent:theEvent];
	}

}



/*
- (void)audioPlayerDidFinishPlaying:(AVAudioPlayer *)player successfully:(BOOL)flag
{
//NSLog(@"audioPlayerDidFinishPlaying");

	// [x] : this is called after more than sound msec

}
*/



@end


#endif // _H_NONNON_MAC_NONNON_GAME



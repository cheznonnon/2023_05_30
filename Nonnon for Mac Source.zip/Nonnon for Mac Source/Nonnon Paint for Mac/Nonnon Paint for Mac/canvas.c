// Project Nonnon
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Template File




#ifndef _H_NONNON_MAC_NONNON_PAINT_CANVAS
#define _H_NONNON_MAC_NONNON_PAINT_CANVAS




#import <Cocoa/Cocoa.h>


#include "../../nonnon/neutral/ini.c"


#include "../../nonnon/mac/_mac.c"
#include "../../nonnon/mac/image.c"




#include "extern.c"




#define N_PAINT_CANVAS_MULTITHREAD


#define N_PAINT_FRAME_ANIM




@protocol NonnonPaint_delegate

- (void) NonnonPaintResize;
- (void) NonnonPaintColorSet;
- (void) NonnonPaintStatus;
- (void) NonnonScrollbarZoomSync:(BOOL)redraw;

@end




@interface NonnonPaintCanvas : NSView

@property (nonatomic,assign) id delegate;

@property n_paint *paint;
@property n_bmp    bmp_canvas;
@property CGFloat  pressure;

@property NonnonTxtbox *txtbox;

- (NSPoint) n_paint_point_on_bitmap;
- (int)     n_paint_zoom_get_int:(int) zoom;
- (void)    n_paint_convert_bitmap2canvas:(void*) zero x:(n_type_gfx*)x y:(n_type_gfx*)y  sx:(n_type_gfx*)sx sy:(n_type_gfx*)sy;
- (void)    display_optimized;
- (n_bmp*)  n_paint_nbmp_get;

#ifdef N_PAINT_FRAME_ANIM
- (void)    n_paint_frame_anim_off;
#endif // #ifdef N_PAINT_FRAME_ANIM

@end




static NonnonPaintCanvas *n_paint_global;




n_posix_bool
n_paint_layer_is_locked( n_type_int i )
{

	n_paint *p = n_paint_global.paint;


	if ( p->layer_onoff == n_posix_false ) { return n_posix_false; }

	if ( p->layer_data[ i ].visible == n_posix_false ) { return n_posix_true; }


	n_posix_char *str = n_txt_get( &p->layer_txt, i );


	return ( str[ 0 ] == n_posix_literal( '*' ) );
}




#ifdef N_PAINT_FRAME_ANIM


#define N_PAINT_FRAME_ANIM_DOT_SIZE ( 8 )


#define N_PAINT_FRAME_ANIM_INTERVAL ( 200 )

static n_posix_bool  n_paint_frame_anim_onoff = n_posix_false;
static n_posix_bool  n_paint_frame_anim_lock  = n_posix_false;
static NSPoint      *n_paint_frame_anim_path  = NULL;
static n_type_int    n_paint_frame_anim_count =    0;
static n_type_int    n_paint_frame_anim_step  =    0;
static NSTimer      *n_paint_frame_anim_timer = nil;
static NSPoint       n_paint_frame_anim_ctl[ 4 ];


#endif // #ifdef N_PAINT_FRAME_ANIM




#include "grabber.c"
#include "pen.c"

#include "frame_anim.c"

#include "layer.c"




@implementation NonnonPaintCanvas {

	NSPoint n_pt;

}


@synthesize delegate;

@synthesize paint;
@synthesize bmp_canvas;
@synthesize pressure;

@synthesize txtbox;




- (instancetype)initWithCoder:(NSCoder *)coder
{
	self = [super initWithCoder:coder];

	if ( self )
	{
		[self registerForDraggedTypes:[NSArray arrayWithObject:NSPasteboardTypeFileURL]];

		n_bmp_zero( &bmp_canvas );

		n_paint_global = self;
	}

	return self;
}




- (BOOL) isFlipped
{
	return YES;
}

- (BOOL) acceptsFirstMouse:(NSEvent *)event
{
//NSLog( @"acceptsFirstMouse" );

	return YES;
}




- (void) NonnonPaintGrabberOnOff:(BOOL)onoff
{
NSLog( @"NonnonPaintGrabberOnOff" );
}




- (n_bmp*) n_paint_nbmp_get
{
	return &bmp_canvas;
}




- (void) n_paint_canvas_reset_cache
{

	if ( paint->layer_data == NULL ) { return; }
	if ( n_bmp_error( &paint->layer_data[ 0 ].bmp_data ) ) { return; }


	static n_type_gfx psx = -1;
	static n_type_gfx psy = -1;

	n_type_gfx bmpsx = N_BMP_SX( &paint->layer_data[ 0 ].bmp_data );
	n_type_gfx bmpsy = N_BMP_SY( &paint->layer_data[ 0 ].bmp_data );

	if ( ( psx != bmpsx )||( psy != bmpsy ) )
	{
		n_bmp_new_fast( &paint->layer_cache_bmp_map , bmpsx, bmpsy );
		n_bmp_new_fast( &paint->layer_cache_bmp_data, bmpsx, bmpsy );
	}

	psx = bmpsx;
	psy = bmpsy;


	n_bmp_flush( &paint->layer_cache_bmp_map , 0 );
	n_bmp_flush( &paint->layer_cache_bmp_data, 0 );

}

- (void) display_optimized
{

	[self n_paint_canvas_reset_cache];

	[self display];

}




- (void) n_paint_draw_frame
{

	if ( paint->grabber_mode )
	{
		n_type_gfx frame_fx, frame_fy, frame_tx, frame_ty;
		n_paint_grabber_system_get( &frame_fx, &frame_fy, &frame_tx, &frame_ty, NULL,NULL );

		if ( paint->zoom > 0 )
		{
			n_type_gfx z = paint->zoom;

			frame_fx *= z;
			frame_fy *= z;
			frame_tx *= z;
			frame_ty *= z;
		} else
		if ( paint->zoom < 0 )
		{
			n_type_gfx z = paint->zoom * -1;

			frame_fx /= z;
			frame_fy /= z;
			frame_tx /= z;
			frame_ty /= z;
		}

		frame_fx -= paint->scroll.x;
		frame_fy -= paint->scroll.y;

		frame_fx += paint->canvas_offset_x;
		frame_fy += paint->canvas_offset_y;

		frame_fx -= 1;
		frame_fy -= 1;
		frame_tx += 2;
		frame_ty += 2;

		n_mac_draw_frame( [NSColor blackColor], NSMakeRect( frame_fx, frame_fy, frame_tx, frame_ty ) );
	}
}




- (void) n_paint_draw:(void*) zero sx:(n_type_gfx)sx sy:(n_type_gfx)sy
{

	int zoom    = [self n_paint_zoom_get_int   :paint->zoom];
	int zoom_ui = [self n_paint_zoom_get_int_ui:paint->zoom];

	n_type_gfx bmpsx = N_BMP_SX( paint->pen_bmp_data );
	n_type_gfx bmpsy = N_BMP_SY( paint->pen_bmp_data );

	if ( paint->zoom < 0 )
	{
		bmpsx /= zoom;
		bmpsy /= zoom;
	} else {
		bmpsx *= zoom;
		bmpsy *= zoom;
	}

	n_type_gfx fx  = 0;
	n_type_gfx fy  = 0;
	n_type_gfx fsx = bmpsx;
	n_type_gfx fsy = bmpsy;
	n_type_gfx tx  = 0;
	n_type_gfx ty  = 0;


	if ( fsx > paint->inner_sx )
	{
		fx  = paint->scroll.x;
		fsx = paint->inner_sx;
	}

	if ( fsy > paint->inner_sy )
	{
		fy  = paint->scroll.y;
		fsy = paint->inner_sy;
	}

	paint->canvas_offset_x = tx = ( sx - fsx ) / 2;
	paint->canvas_offset_y = ty = ( sy - fsy ) / 2;

	paint->canvas_offset_sx = (CGFloat) fsx;
	paint->canvas_offset_sy = (CGFloat) fsy;


	n_type_gfx gx,gy,gsx,gsy; n_paint_grabber_system_get( &gx,&gy, &gsx,&gsy, NULL,NULL );


	// [!] : redraw area

	n_type_gfx rx;
	n_type_gfx ry;
	n_type_gfx rsx;
	n_type_gfx rsy;

	n_mac_rect_expand_size( paint->rect_redraw, &rx, &ry, &rsx, &rsy );

	rx  -= zoom_ui;
	ry  -= zoom_ui;
	rsx += zoom_ui;
	rsy += zoom_ui;


	// [!] : grid

	n_type_gfx center_x = bmpsx / 2;
	n_type_gfx center_y = bmpsy / 2;

	center_x /= zoom_ui;
	center_y /= zoom_ui;

	n_type_gfx grid_x = bmpsx / 8;
	n_type_gfx grid_y = bmpsx / 8;

	grid_x /= zoom_ui;
	grid_y /= zoom_ui;


	// [!] : optimization

	if ( paint->zoom < 0 )
	{
		fx = ( fx * zoom );
		fy = ( fy * zoom );
	} else {
		fx = ( fx / zoom );
		fy = ( fy / zoom );
	}


#ifdef N_PAINT_CANVAS_MULTITHREAD

	// [!] : multi-thread

	n_posix_bool prv = n_bmp_is_multithread;
	n_bmp_is_multithread = n_posix_true;

#endif // #ifdef N_PAINT_CANVAS_MULTITHREAD


	// [!] : Y axis

	n_type_gfx  y = 0;
	n_type_gfx zy = 0;
	n_posix_loop
	{


#ifdef N_PAINT_CANVAS_MULTITHREAD

	// [!] : multi-thread

	NSOperation *o = [NSBlockOperation blockOperationWithBlock:^{

#endif // #ifdef N_PAINT_CANVAS_MULTITHREAD


	// [!] : X axis : singleline

	n_type_gfx  x = 0;
	n_type_gfx zx = 0;
	n_posix_loop
	{

		if (
			( ( tx + x ) >= rx )
			&&
			( ( ty + y ) >= ry )
			&&
			( ( tx + x ) <= ( rx + rsx ) )
			&&
			( ( ty + y ) <= ( ry + rsy ) )
		)
		{

			n_type_gfx xx,yy;

			if ( self->paint->zoom < 0 )
			{
				xx = fx + ( x * zoom );
				yy = fy + ( y * zoom );
			} else {
				xx = fx + zx;
				yy = fy + zy;
			}

			u32 color; //n_bmp_ptr_get_fast( paint->pen_bmp_data, xx,yy, &color );

			if ( n_posix_false == n_bmp_ptr_is_accessible( self->paint->pen_bmp_data, xx,yy ) )
			{
				color = N_PAINT_CANVAS_COLOR;
			} else
			if ( self->paint->layer_onoff )
			{
				color = n_bmp_layer_ptr_get( self->paint->layer_data, xx,yy, n_posix_false, 0, n_posix_true );
			} else {
				n_paint_grabber_pixel_get( xx,yy, self->paint->color, &color, NULL, 0.00 );
			}
//color = n_bmp_rgb_mac( 0,200,255 );


			// [!] : grabber

			if ( self->paint->grabber_mode != N_PAINT_GRABBER_NEUTRAL )
			{

				if ( self->paint->grabber_per_pixel_alpha_onoff )
				{
					int alpha = n_bmp_a( color );

					u32 c; n_bmp_ptr_get_fast( self->paint->pen_bmp_data, xx,yy, &c );
					color = n_bmp_blend_pixel( color, c, n_bmp_blend_alpha2ratio( alpha ) );
				}

				if ( self->paint->layer_onoff == FALSE )
				{
					if ( self->paint->grabber_blend )
					{
						u32 c; n_bmp_ptr_get_fast( self->paint->pen_bmp_data, xx,yy, &c );
						color = n_bmp_blend_pixel( color, c, self->paint->grabber_blend_ratio );
					}
				}

			}


			// [!] : checker background

			int alpha = n_bmp_a( color );

			if ( N_BMP_ALPHA_CHANNEL_VISIBLE != alpha )
			{
				u32 c = n_paint_bmp_checker_pixel( xx, yy, N_BMP_SX( self->paint->pen_bmp_data ), N_BMP_SY( self->paint->pen_bmp_data ), N_PAINT_CANVAS_COLOR );
				color = n_bmp_blend_pixel( color, c, n_bmp_blend_alpha2ratio( alpha ) );
			}


			if ( zoom < 0 )
			{

				n_bmp_ptr_set_fast( &self->bmp_canvas, tx + x, ty + y, color );

			} else {
//n_bmp_box( &bmp_canvas, tx + x, ty + y, zoom_ui, zoom_ui, color );

				n_type_gfx bx = 0;
				n_type_gfx by = 0;
				n_posix_loop
				{//break;

					u32 c = color;


					// [!] : grid

					if ( ( self->paint->grid_onoff )&&( self->paint->zoom > 0 ) )
					{
						if ( ( xx == center_x )||( yy == center_y ) )
						{
							if ( ( bx == 0 )||( by == 0 )||( bx == ( zoom_ui - 1 ) )||( by == ( zoom_ui - 1 ) ) )
							{
								c = n_bmp_blend_pixel( c, n_bmp_rgb_mac( 255,0,128 ), 0.25 );
							}
						} else
						if ( ( ( xx % grid_x ) == 0 )||( ( yy % grid_y ) == 0 ) )
						{
							if ( ( bx == 0 )||( by == 0 )||( bx == ( zoom_ui - 1 ) )||( by == ( zoom_ui - 1 ) ) )
							{
								c = n_bmp_blend_pixel( c, n_bmp_rgb_mac( 0,200,255 ), 0.25 );
							}
						}
					}


					// [!] : pixel grid

					if ( ( self->paint->pixel_grid_onoff )&&( zoom_ui >= 3 ) )
					{
						if ( ( bx == 0 )||( by == 0 )||( bx == ( zoom_ui - 1 ) )||( by == ( zoom_ui - 1 ) ) )
						{
							c = n_bmp_blend_pixel( c, n_bmp_rgb_mac( 0,200,255 ), 0.25 );
						}
					}

					n_bmp_ptr_set( &self->bmp_canvas, tx + x + bx, ty + y + by, c );

					bx++;
					if ( bx >= zoom_ui )
					{
						bx = 0;

						by++;
						if ( by >= zoom_ui ) { break; }
					}
				}

			}

		}

		x += zoom_ui; zx++;
		if ( x >= fsx ) { break; }
	}


#ifdef N_PAINT_CANVAS_MULTITHREAD

	// [!] : multi-thread

	}];
	[paint->queue addOperation:o];

#endif // #ifdef N_PAINT_CANVAS_MULTITHREAD


	// [!] : Y axis

	y += zoom_ui; zy += 1;
	if ( y >= fsy ) { break; }

	}


#ifdef N_PAINT_CANVAS_MULTITHREAD

	// [!] : multi-thread

	[paint->queue waitUntilAllOperationsAreFinished];

	n_bmp_is_multithread = prv;

#endif // #ifdef N_PAINT_CANVAS_MULTITHREAD


	return;
}

-(void) drawRect:(NSRect) rect
{
//NSLog( @"drawRect" );


	// [Needed] : always needed

	[self n_paint_scroll_clamp];


	if ( paint->layer_load_onoff )
	{
		paint->layer_load_onoff = FALSE;

		NSString *text = [NSString stringWithFormat:@"%0.0f%%", paint->layer_load_percent];

		NSMutableDictionary *attr = [NSMutableDictionary dictionary];

		NSFont  *font     = [NSFont fontWithName:@"Trebuchet MS" size:33];
		NSColor *color_fg = [NSColor whiteColor];
		NSColor *color_bg = n_mac_argb2nscolor( N_PAINT_CANVAS_COLOR );

		[attr setObject:font     forKey:NSFontAttributeName           ];
		[attr setObject:color_fg forKey:NSForegroundColorAttributeName];

		CGFloat isx = rect.size.width;
		CGFloat isy = rect.size.height;

		CGSize size = n_mac_image_text_pixelsize( text, font );

		NSRect rect_centered = NSMakeRect
		(
			( ( isx - size.width  ) / 2 ),
			( ( isy - size.height ) / 2 ),
			size.width,
			size.height
		);

		n_mac_draw_box( color_bg, rect );
		[text drawInRect:rect_centered withAttributes:attr];

		return;
	}


	paint->rect_redraw = rect;


	BOOL is_flushed = FALSE;

	static n_type_gfx prv_sx = -1;
	static n_type_gfx prv_sy = -1;

	n_type_gfx sx = NSWidth ( self.frame );
	n_type_gfx sy = NSHeight( self.frame );

	if ( NULL == N_BMP_PTR( &bmp_canvas ) )
	{
		n_bmp_new_fast( &bmp_canvas, sx,sy );

		is_flushed = TRUE;
		n_bmp_flush( &bmp_canvas, N_PAINT_CANVAS_COLOR );
	}

	if ( ( prv_sx != sx )||( prv_sy != sy ) )
	{
		if ( is_flushed == FALSE )
		{
			n_bmp_flush( &bmp_canvas, N_PAINT_CANVAS_COLOR );
		}
	}


	if ( paint->init == FALSE )
	{
		NSRect rect_canvas = NSMakeRect( 0,0,sx,sy );
		n_mac_image_nbmp_direct_draw( &bmp_canvas, &rect_canvas, NO );

		return;
	}


	static BOOL scroll_x_onoff = FALSE;
	static BOOL scroll_y_onoff = FALSE;

	BOOL prv_scroll_x_onoff = scroll_x_onoff;
	BOOL prv_scroll_y_onoff = scroll_y_onoff;

	{

		// [!] : Fake Scroller : Calc Only : Horizontal

		CGFloat zoom = [self n_paint_zoom_get_ratio:paint->zoom];

		CGFloat csx              = sx;
		CGFloat items_per_canvas = paint->inner_sx;
		CGFloat max_count        = (CGFloat) N_BMP_SX( paint->pen_bmp_data ) * zoom;

		max_count += zoom;

		if ( trunc( items_per_canvas ) < max_count )
		{
//NSLog( @"%f %f", items_per_canvas, max_count );

			scroll_x_onoff = TRUE;

			CGFloat shaft = csx - paint->scroller_size;
			CGFloat page  = max_count / items_per_canvas;

			CGFloat scrsx = n_posix_max_n_type_real( paint->scroller_size, ( items_per_canvas / page ) + paint->margin - paint->scroller_size );
			CGFloat scrsy = paint->scroller_size;
			CGFloat scr_x = ( paint->scroll.x / max_count ) * items_per_canvas;
			CGFloat scr_y = sy - scrsy;
//NSLog( @"%f %f %f %f", scr_x, scr_y, scrsx, scrsy );


			// [!] : for hit test

			paint->scroller_x_rect_shaft = NSMakeRect(     0, scr_y, shaft, scrsy );
			paint->scroller_x_rect_thumb = NSMakeRect( scr_x, scr_y, scrsx, scrsy );

		} else {
//NSLog( @"2" );
			scroll_x_onoff = FALSE;
			paint->scroll.x  = 0;

		}

	}

	{

		// [!] : Fake Scroller : Calc Only : Vertical

		CGFloat zoom = [self n_paint_zoom_get_ratio:paint->zoom];

		CGFloat csy              = sy;
		CGFloat items_per_canvas = paint->inner_sy;
		CGFloat max_count        = (CGFloat) N_BMP_SY( paint->pen_bmp_data ) * zoom;

		max_count += zoom;

		if ( trunc( items_per_canvas ) < max_count )
		{

			scroll_y_onoff = TRUE;

			CGFloat shaft = csy - paint->scroller_size;
			CGFloat page  = max_count / items_per_canvas;

			CGFloat scrsx = paint->scroller_size;
			CGFloat scrsy = n_posix_max_n_type_real( paint->scroller_size, ( items_per_canvas / page ) + paint->margin - paint->scroller_size );
			CGFloat scr_x = sx - scrsx;
			CGFloat scr_y = ( paint->scroll.y / max_count ) * items_per_canvas;


			// [!] : for hit test

			paint->scroller_y_rect_shaft = NSMakeRect( scr_x,     0, scrsx, shaft );
			paint->scroller_y_rect_thumb = NSMakeRect( scr_x, scr_y, scrsx, scrsy );

		} else {

			scroll_y_onoff = FALSE;
			paint->scroll.y  = 0;

		}

	}

	if (
		( prv_scroll_x_onoff != scroll_x_onoff )
		||
		( prv_scroll_y_onoff != scroll_y_onoff )
	)
	{
		if ( is_flushed == FALSE )
		{
			n_bmp_flush( &bmp_canvas, N_PAINT_CANVAS_COLOR );
		}
	}


	// [!] : Combined Scale Copy

	[self n_paint_draw:nil sx:sx sy:sy];

	paint->redraw_type = N_PAINT_REDRAW_TYPE_ALL;


	if ( scroll_x_onoff )
	{
//NSLog( @" 1 " );

		// [!] : Fake Scroller : Draw : Horizontal


		// [!] : shaft

		{
			n_type_gfx  x = paint->scroller_x_rect_shaft.origin.x;
			n_type_gfx  y = paint->scroller_x_rect_shaft.origin.y;
			n_type_gfx sx = paint->scroller_x_rect_shaft.size.width;
			n_type_gfx sy = paint->scroller_x_rect_shaft.size.height;
//NSLog( @"Shaft : %d %d %d %d", x,y,sx,sy );

			u32 color_shaft = n_bmp_rgb_mac( 244,244,244 );
			n_bmp_roundrect( &bmp_canvas, x,y,sx,sy, color_shaft, 50 );
		}


		// [!] : thumb / knob

		int alpha_fade_bg;
		int alpha_fade_fg;
		if ( paint->scroller_fade.color_fg == n_bmp_white )
		{
			alpha_fade_bg = 64;
			alpha_fade_fg = 96;
		} else {
			alpha_fade_bg = 96;
			alpha_fade_fg = 64;
		}
		int alpha = 255;//n_bmp_blend_channel( alpha_fade_bg, alpha_fade_fg, (double) fade_scroll.percent * 0.01 );
//NSLog( @"%d", fade.percent );

		{
			n_type_gfx  x = paint->scroller_x_rect_thumb.origin.x;
			n_type_gfx  y = paint->scroller_x_rect_thumb.origin.y;
			n_type_gfx sx = paint->scroller_x_rect_thumb.size.width;
			n_type_gfx sy = paint->scroller_x_rect_thumb.size.height;
//NSLog( @"Thumb : %d %d %d %d", x,y,sx,sy );

			u32 color       = n_bmp_rgb_mac( 200,200,200 );
			u32 color_thumb = n_bmp_alpha_replace_pixel( color, alpha );
			n_bmp_roundrect( &bmp_canvas, x,y,sx,sy, color_thumb, 50 );
		}

	}

	if ( scroll_y_onoff )
	{

		// [!] : Fake Scroller : Draw : Vertical


		// [!] : shaft

		{
			n_type_gfx  x = paint->scroller_y_rect_shaft.origin.x;
			n_type_gfx  y = paint->scroller_y_rect_shaft.origin.y;
			n_type_gfx sx = paint->scroller_y_rect_shaft.size.width;
			n_type_gfx sy = paint->scroller_y_rect_shaft.size.height;

			u32 color_shaft = n_bmp_rgb_mac( 244,244,244 );
			n_bmp_roundrect( &bmp_canvas, x,y,sx,sy, color_shaft, 50 );
		}


		// [!] : thumb / knob

		int alpha_fade_bg;
		int alpha_fade_fg;
		if ( paint->scroller_fade.color_fg == n_bmp_white )
		{
			alpha_fade_bg = 64;
			alpha_fade_fg = 96;
		} else {
			alpha_fade_bg = 96;
			alpha_fade_fg = 64;
		}
		int alpha = 255;//n_bmp_blend_channel( alpha_fade_bg, alpha_fade_fg, (double) fade_scroll.percent * 0.01 );
//NSLog( @"%d", fade.percent );

		{
			n_type_gfx  x = paint->scroller_y_rect_thumb.origin.x;
			n_type_gfx  y = paint->scroller_y_rect_thumb.origin.y;
			n_type_gfx sx = paint->scroller_y_rect_thumb.size.width;
			n_type_gfx sy = paint->scroller_y_rect_thumb.size.height;

			u32 color       = n_bmp_rgb_mac( 200,200,200 );
			u32 color_thumb = n_bmp_alpha_replace_pixel( color, alpha );
			n_bmp_roundrect( &bmp_canvas, x,y,sx,sy, color_thumb, 50 );
		}

	}

/*
	if ( paint->grabber_mode )
	{

		n_type_gfx frame_fx, frame_fy, frame_tx, frame_ty;
		n_paint_grabber_system_get( &frame_fx, &frame_fy, &frame_tx, &frame_ty, NULL,NULL );

		frame_fx += paint->canvas_offset_x;
		frame_fy += paint->canvas_offset_y;

n_bmp_box( &bmp_canvas, frame_fx, frame_fy, frame_tx, frame_ty, n_bmp_rgb_mac( 0,200,255 ) );

	}
*/

#ifdef N_PAINT_FRAME_ANIM

	if ( ( paint->zoom > 0 )&&( paint->grabber_mode ) )
	{

		n_type_gfx bitmap_sx = N_BMP_SX( paint->pen_bmp_data );
		n_type_gfx bitmap_sy = N_BMP_SY( paint->pen_bmp_data );


		n_type_gfx frame_fx, frame_fy, frame_tx, frame_ty;
		n_paint_grabber_system_get( &frame_fx, &frame_fy, &frame_tx, &frame_ty, NULL,NULL );

		// [!] : canvas_offset_x/y : valid after combined scale copy

		frame_tx += frame_fx;
		frame_ty += frame_fy;

		// [!] : animated frame
		n_paint_frame_anim_init( bitmap_sx,bitmap_sy, frame_fx, frame_fy, frame_tx, frame_ty );

		n_paint_frame_anim_exit( paint, &bmp_canvas );

	}

	{
		NSRect rect_canvas = NSMakeRect( 0,0,sx,sy );
		n_mac_image_nbmp_direct_draw( &bmp_canvas, &rect_canvas, NO );
	}

	if ( paint->zoom < 0 )
	{
		[self n_paint_draw_frame];
	}

#else  // #ifdef N_PAINT_FRAME_ANIM

	{
		NSRect rect_canvas = NSMakeRect( 0,0,sx,sy );
		n_mac_image_nbmp_direct_draw( &bmp_canvas, &rect_canvas, NO );
	}

	[self n_paint_draw_frame];

#endif // #ifdef N_PAINT_FRAME_ANIM

}




- (CGFloat) n_paint_zoom_get_ratio:(CGFloat) zoom
{
	if ( zoom < 0 ) { zoom = 1.0 / ( zoom * -1 ); }

//NSLog( @"%0.2f", zoom );
	return zoom;
}

- (int) n_paint_zoom_get_int:(int) zoom
{
	if ( zoom < 0 ) { zoom *= -1; }

//NSLog( @"%d", zoom );
	return zoom;
}

- (int) n_paint_zoom_get_int_ui:(int) zoom
{
	if ( zoom < 0 ) { zoom = 1; }

	return zoom;
}

- (NSPoint) n_paint_point_on_bitmap
{

	// [Needed] : calc by integer is absolutely needed


	NSPoint pt = n_mac_cursor_position_get( self );

//NSLog( @"%f %f", pt.x, pt.y );

	n_type_gfx pt_x = pt.x;
	n_type_gfx pt_y = pt.y;


	pt_x -= paint->margin / 2;
	pt_y -= paint->margin / 2;

//NSLog( @"%f %f", pt.x, pt.y );


	n_type_real ratio = [self n_paint_zoom_get_ratio:paint->zoom];
	n_type_real zoom  = [self n_paint_zoom_get_int  :paint->zoom];


	n_type_gfx scr_x = paint->scroll.x;
	n_type_gfx scr_y = paint->scroll.y;

	if ( paint->zoom > 0 )
	{
		pt_x += scr_x / zoom * zoom;
		pt_y += scr_y / zoom * zoom;
	} else {
		pt_x += scr_x;
		pt_y += scr_y;
	}


	n_type_gfx bmpsx = N_BMP_SX( paint->pen_bmp_data ) * ratio;
	n_type_gfx bmpsy = N_BMP_SY( paint->pen_bmp_data ) * ratio;

	if ( paint->inner_sx > bmpsx )
	{
		pt_x -= ( paint->inner_sx - bmpsx ) / 2;
	}

	if ( paint->inner_sy > bmpsy )
	{
		pt_y -= ( paint->inner_sy - bmpsy ) / 2;
	}

	pt_x /= ratio;
	pt_y /= ratio;


	return NSMakePoint( pt_x, pt_y );
}

- (void) n_paint_convert_bitmap2canvas:(void*) zero x:(n_type_gfx*)x y:(n_type_gfx*)y sx:(n_type_gfx*)sx sy:(n_type_gfx*)sy
{

	CGFloat ratio = [self n_paint_zoom_get_ratio:paint->zoom];
//NSLog( @"%f", ratio );

	n_type_gfx osetx = paint->canvas_offset_x;
	n_type_gfx osety = paint->canvas_offset_y;
	n_type_gfx scr_x = paint->scroll.x;
	n_type_gfx scr_y = paint->scroll.y;
//NSLog( @"%d %d", osety ,scr_y );
//NSLog( @"%f", paint->scroll.y );

	if (  x != NULL ) { (* x) = osetx + ( (*x) * ratio ) - scr_x; }
	if (  y != NULL ) { (* y) = osety + ( (*y) * ratio ) - scr_y; }
	if ( sx != NULL ) { (*sx) = (*sx) * ratio; }
	if ( sy != NULL ) { (*sy) = (*sy) * ratio; }

}




- (void) n_paint_scroll_clamp
{

	if ( paint->scroll.x < 0 ) { paint->scroll.x = 0; }
	if ( paint->scroll.y < 0 ) { paint->scroll.y = 0; }

	CGFloat zoom = [self n_paint_zoom_get_ratio:paint->zoom];

	CGFloat max_sx = ( N_BMP_SX( paint->pen_bmp_data ) * zoom ) - paint->inner_sx + zoom;
	CGFloat max_sy = ( N_BMP_SY( paint->pen_bmp_data ) * zoom ) - paint->inner_sy + zoom;;

	if ( paint->scroll.x >= max_sx ) { paint->scroll.x = max_sx; }
	if ( paint->scroll.y >= max_sy ) { paint->scroll.y = max_sy; }


	if ( paint->scroller_clamp == FALSE )
	{
		n_type_gfx zoom_ui = [self n_paint_zoom_get_int_ui:paint->zoom];

		n_type_gfx scr_x = paint->scroll.x;
		n_type_gfx scr_y = paint->scroll.y;

		scr_x = scr_x / zoom_ui * zoom_ui;
		scr_y = scr_y / zoom_ui * zoom_ui;

		paint->scroll.x = scr_x;
		paint->scroll.y = scr_y;
	}

	paint->scroller_clamp = FALSE;

}




#ifdef N_PAINT_FRAME_ANIM

- (void) n_paint_frame_anim_timer_method
{
//NSLog( @"n_paint_frame_anim_timer_method" );

	if ( paint->resizer_onoff ) { return; }

	if ( paint->tooltype != N_PAINT_TOOL_TYPE_GRABBER ) { return; }

	if ( n_paint_global.paint->zoom < 1 ) { return; }

//NSLog( @"%d", paint->grabber_mode );
	if (
		( paint->grabber_mode == N_PAINT_GRABBER_DRAG_OK )
		||
		( paint->grabber_mode == N_PAINT_GRABBER_DRAGGING )
		||
		( paint->grabber_mode == N_PAINT_GRABBER_STRETCH_PROPORTIONAL )
		||
		( paint->grabber_mode == N_PAINT_GRABBER_STRETCH_TRANSFORM )
	)
	{
		//static u32 timer = 0;
		//if ( n_game_timer( &timer, 200 ) )
		{
			n_paint_frame_anim_step++;
			if (
				( paint->grabber_mode == N_PAINT_GRABBER_DRAG_OK )
				||
				( paint->grabber_mode == N_PAINT_GRABBER_DRAGGING )
			)
			{
				n_paint_grabber_resync_auto();
			}
		}
	}

}

- (void) n_paint_frame_anim_off
{
//NSLog( @"n_paint_frame_anim_off" );

	n_mac_timer_exit( n_paint_frame_anim_timer );
	n_paint_frame_anim_timer = nil;

	n_paint_frame_anim_onoff = n_posix_false;

}

- (void) n_paint_frame_anim_on
{
//NSLog( @"n_paint_frame_anim_on" );

//NSLog( @"n_paint_frame_anim_on : %d %d", paint->tooltype, paint->grabber_mode ); return;

	if ( paint->tooltype != N_PAINT_TOOL_TYPE_GRABBER ) { return; }

	if ( n_paint_frame_anim_timer == nil )
	{
		n_paint_frame_anim_timer = n_mac_timer_init( n_paint_global, @selector( n_paint_frame_anim_timer_method ), N_PAINT_FRAME_ANIM_INTERVAL );
	}

	n_paint_frame_anim_step  = 0;
	n_paint_frame_anim_onoff = n_posix_true;

}

#endif // #ifdef N_PAINT_FRAME_ANIM




- (void) updateTrackingAreas
{
//return;

	int options = (
		NSTrackingMouseEnteredAndExited |
		NSTrackingMouseMoved            |
		NSTrackingActiveAlways          |
		NSTrackingActiveInActiveApp
	);

	NSTrackingArea *trackingArea = [
		[NSTrackingArea alloc]
			initWithRect:[self bounds]
			     options:options
			       owner:self
			    userInfo:nil
	];
	
	[self addTrackingArea:trackingArea];

}
/*
- (void) resetCursorRects
{
//NSLog(@"resetCursorRects");

	// [x] : buggy : maybe impossible to implement accurate behavior
	//
	//	[cursor set]     : applied globally
	//	mouseMoved       : delay will occur
	//	at launch time   : always arrow cursor
	//	push/pop         : more complicated behavior happens
	//	resetCursorRects : not refreshed on inactive window

	//[NSCursor hide];

	//return;


	// [Patch]

	NSRect rect = NSMakeRect(
		self.bounds.origin.x    +   paint->scroller_size,
		self.bounds.origin.y    +   paint->scroller_size,
		self.bounds.size.width  - ( paint->scroller_size * 2 ),
		self.bounds.size.height - ( paint->scroller_size * 2 )
	);

	//[self discardCursorRects];

	[self removeCursorRect:rect cursor:paint->cursor_arrow  ];
	[self removeCursorRect:rect cursor:paint->cursor_no     ];
	[self removeCursorRect:rect cursor:paint->cursor_hand   ];
	[self removeCursorRect:rect cursor:paint->cursor_pen_on ];
	[self removeCursorRect:rect cursor:paint->cursor_pen_off];
	[self removeCursorRect:rect cursor:paint->cursor_eraser ];

	//[self.window invalidateCursorRectsForView:self];
	//[self.window invalidateCursorRectsForView:self];

	if ( paint->readonly )
	{
		//[[NSCursor arrowCursor] set];
		[self addCursorRect:rect cursor:paint->cursor_arrow];
	} else
	if (
		( paint->layer_onoff )
		&&
		(
			( paint->layer_data[ paint->layer_index ].visible == FALSE )
			||
			( n_paint_layer_is_locked( paint->layer_index ) )
		)
	)
	{
		[self addCursorRect:rect cursor:paint->cursor_no];
	} else
	if ( paint->cursor_grab_n_drag_onoff )
	{
		[self addCursorRect:rect cursor:paint->cursor_hand];
	} else
	if ( paint->tooltype == N_PAINT_TOOL_TYPE_PEN )
	{
		if ( paint->pen_quick_eraser_onoff )
		{
			//[paint->cursor_eraser set];
			[self addCursorRect:rect cursor:paint->cursor_eraser ];
		} else
		if ( paint->pen_start )
		{
			//[paint->cursor_pen_on set];
			[self addCursorRect:rect cursor:paint->cursor_pen_on ];
		} else {
			//[paint->cursor_pen_off set];
			[self addCursorRect:rect cursor:paint->cursor_pen_off];
		}
	} else {
		//[[NSCursor arrowCursor] set];
		[self addCursorRect:rect cursor:paint->cursor_arrow];
	}

}
*/
- (BOOL) n_paint_is_not_canvas
{

	// [!] : skip canvas window
	n_type_int i = 1;
	n_posix_loop
	{
		if ( paint->nswindow[ i ] == nil ) { break; }

		if ( [paint->nswindow[ i ] isKeyWindow] )
		{
			return TRUE;
		}

		i++;
	}


	return FALSE;
}

- (void) resetCursorRects
{
//NSLog(@"resetCursorRects2");

//NSLog( @"%d", n_paint_frame_anim_onoff );

	NSPoint pt = n_mac_cursor_position_get( self );

	if ( paint->is_about_window )
	{
		[paint->cursor_arrow set];
	} else
	if (
		( pt.x < 0 )
		||
		( pt.y < 0 )
		||
		( pt.x > ( [self frame].size.width  - paint->scroller_size ) )
		||
		( pt.y > ( [self frame].size.height - paint->scroller_size ) )
	)
	{
//NSLog( @"out of canvas : %d", paint->pen_start );

		if ( paint->cursor_grab_n_drag_onoff )
		{
			[paint->cursor_hand set];
		} else
		if ( paint->pen_start )
		{
			[paint->cursor_pen_on set];
		} else {
			[paint->cursor_arrow set];
		}
	} else
	if ( [paint->nswindow[ 0 ] isKeyWindow] == FALSE )
	{
//NSLog( @"key window #1 : %d", paint->pen_start );
		//[paint->cursor_arrow set];
	} else
	if ( [self n_paint_is_not_canvas] )
	{
//NSLog( @"key window #2: %d", paint->pen_start );
		//[paint->cursor_arrow set];
	} else
	if (
		( paint->layer_onoff )
		&&
		(
			( paint->layer_data[ paint->layer_index ].visible == FALSE )
			||
			( n_paint_layer_is_locked( paint->layer_index ) )
		)
	)
	{
		[paint->cursor_no set];
	} else
#ifdef N_PAINT_FRAME_ANIM
	if ( n_paint_frame_anim_onoff )
	{
//NSLog( @"type %d : start %d", paint->tooltype, paint->pen_start );
		if ( paint->tooltype == N_PAINT_TOOL_TYPE_PEN )
		{
			if ( paint->pen_quick_eraser_onoff )
			{
				[paint->cursor_eraser set];
			} else
			if ( paint->pen_quick_blur_onoff )
			{
				[paint->cursor_blur set];
			} else
			if ( paint->pen_start )
			{
				[paint->cursor_pen_on set];
			} else {
				[paint->cursor_pen_off set];
			}
		} else {
			int i = n_paint_frame_resize_dot_detect( paint );
//NSLog( @"%d", i );
			if ( i == -1 )
			{
				[paint->cursor_arrow set];
				paint->cursor_resize_dragging = paint->cursor_arrow;
			} else
			if ( ( i == 0 )||( i == 2 ) )
			{
				[paint->cursor_resize_ne set];
				paint->cursor_resize_dragging = paint->cursor_resize_ne;
			} else {
				[paint->cursor_resize_nw set];
				paint->cursor_resize_dragging = paint->cursor_resize_nw;
			}
		}
	} else
#endif // #ifdef N_PAINT_FRAME_ANIM
	if ( paint->readonly )
	{
//NSLog( @"read-only" );
		[paint->cursor_arrow set];
	} else
	if ( paint->cursor_grab_n_drag_onoff )
	{
		[paint->cursor_hand set];
	} else
	if ( paint->tooltype == N_PAINT_TOOL_TYPE_PEN )
	{
//NSLog( @"N_PAINT_TOOL_TYPE_PEN" );
		if ( paint->pen_quick_eraser_onoff )
		{
			[paint->cursor_eraser set];
		} else
		if ( paint->pen_quick_blur_onoff )
		{
			[paint->cursor_blur set];
		} else
		if ( paint->pen_start )
		{
			[paint->cursor_pen_on set];
		} else {
			[paint->cursor_pen_off set];
		}
	} else {
//NSLog( @"N/A %d", paint->pen_start );

		[paint->cursor_arrow set];
	}

}

- (void) mouseEntered:(NSEvent *)theEvent
{
//NSLog(@"mouseEntered");

	// [Needed] : NSTrackingMouseEnteredAndExited

	[self.window makeKeyWindow];
	[self resetCursorRects];

}

- (void) mouseExited:(NSEvent *)theEvent
{
//NSLog(@"mouseExited");

	// [Needed] : NSTrackingMouseEnteredAndExited

}

- (void) mouseMoved:(NSEvent *)theEvent
{
//NSLog( @"mouseMoved" );

	// [Needed] : NSTrackingMouseMoved
	//[self.delegate mouseMoved:theEvent];

	[n_paint_global.delegate NonnonPaintStatus];

	[self resetCursorRects];

}




- (void) mouseUp:(NSEvent*) theEvent
{
//NSLog( @"mouseUp" );


	paint->scroller_thumb_is_captured = FALSE;

	paint->scroller_x_offset = -1;
	paint->scroller_y_offset = -1;


	if ( paint->readonly ) { return; }


	NonnonPaintPen_mouseUp( paint );
	NonnonPaintGrabber_mouseUp( paint );


	[self resetCursorRects];

}

- (void) mouseDown:(NSEvent*) theEvent
{
//NSLog(@"mouseDown");

//NSPoint pt = [self n_paint_point_on_bitmap];
//NSLog( @"%0.2f %0.2f", pt.x, pt.y );
//n_bmp_circle( paint->pen_bmp_data, pt.x-16,pt.y-16,32,32, n_bmp_rgb_mac( 0,200,255 ) );
//[self display];

	paint->scroller_x_thumb_is_hovered = n_mac_window_is_hovered_offset_by_rect( self, paint->scroller_x_rect_thumb );
	paint->scroller_x_shaft_is_hovered = n_mac_window_is_hovered_offset_by_rect( self, paint->scroller_x_rect_shaft );
	paint->scroller_y_thumb_is_hovered = n_mac_window_is_hovered_offset_by_rect( self, paint->scroller_y_rect_thumb );
	paint->scroller_y_shaft_is_hovered = n_mac_window_is_hovered_offset_by_rect( self, paint->scroller_y_rect_shaft );


	NSPoint pt_cur = n_mac_cursor_position_get( self );

	if ( paint->scroller_x_thumb_is_hovered )
	{
		paint->scroller_x_offset = pt_cur.x - paint->scroller_x_rect_thumb.origin.x;
	} else {
		paint->scroller_x_offset = -1;
	}

	if ( paint->scroller_y_thumb_is_hovered )
	{
		paint->scroller_y_offset = pt_cur.y - paint->scroller_y_rect_thumb.origin.y;
	} else {
		paint->scroller_y_offset = -1;
	}


	if ( ( paint->scroller_x_thumb_is_hovered )||( paint->scroller_y_thumb_is_hovered ) )
	{
		paint->scroller_thumb_is_captured = TRUE;
	} else
	if ( paint->scroller_x_shaft_is_hovered )
	{
		CGFloat zoom = [self n_paint_zoom_get_ratio:paint->zoom];

		CGFloat items_per_canvas = paint->inner_sx;
		CGFloat max_count        = (CGFloat) N_BMP_SX( paint->pen_bmp_data ) * zoom;

		paint->scroll.x = pt_cur.x - ( NSWidth( paint->scroller_x_rect_thumb )/ 2 );
		paint->scroll.x = ( paint->scroll.x / items_per_canvas ) * max_count;

		[self display];
	} else
	if ( paint->scroller_y_shaft_is_hovered )
	{
		CGFloat zoom = [self n_paint_zoom_get_ratio:paint->zoom];

		CGFloat items_per_canvas = paint->inner_sy;
		CGFloat max_count        = (CGFloat) N_BMP_SY( paint->pen_bmp_data ) * zoom;

		paint->scroll.y = pt_cur.y - ( NSHeight( paint->scroller_y_rect_thumb )/ 2 );
		paint->scroll.y = ( paint->scroll.y / items_per_canvas ) * max_count;

		[self display];
	} else {

		// [!] : for traditional Mac mice like Magic Mouse
		NSUInteger flags = [[NSApp currentEvent] modifierFlags];
		if ( flags & NSEventModifierFlagShift )
		{
			[self rightMouseDown:theEvent];
			return;
		}


		if ( paint->readonly ) { return; }


#ifdef N_PAINT_FRAME_ANIM

		[self n_paint_frame_anim_on];

		n_paint_frame_mouseDown( paint );

#endif // #ifdef N_PAINT_FRAME_ANIM

		pressure = [theEvent pressure];

		NonnonPaintPen_mouseDown( paint );
		NonnonPaintGrabber_mouseDown( paint, theEvent );

		[self resetCursorRects];

	}

}

- (void) mouseDragged:(NSEvent*) theEvent
{
//NSLog( @"mouseDragged" );

	if ( paint->scroller_thumb_is_captured )
	{
		NSPoint pt_cur = n_mac_cursor_position_get( self );

		CGFloat zoom = [self n_paint_zoom_get_ratio:paint->zoom];

		if ( paint->scroller_x_thumb_is_hovered )
		{
			CGFloat items_per_canvas = paint->inner_sx;
			CGFloat max_count        = (CGFloat) N_BMP_SX( paint->pen_bmp_data ) * zoom;

			paint->scroll.x = pt_cur.x - paint->scroller_x_offset;
			paint->scroll.x = ( paint->scroll.x / items_per_canvas ) * max_count;
		}

		if ( paint->scroller_y_thumb_is_hovered )
		{
			CGFloat items_per_canvas = paint->inner_sy;
			CGFloat max_count        = (CGFloat) N_BMP_SY( paint->pen_bmp_data ) * zoom;

			paint->scroll.y = pt_cur.y - paint->scroller_y_offset;
			paint->scroll.y = ( paint->scroll.y / items_per_canvas ) * max_count;
		}

		[self display];
	} else {
		if ( paint->readonly ) { return; }

		pressure = [theEvent pressure];

		NonnonPaintPen_mouseDragged( paint );
		NonnonPaintGrabber_mouseDragged( paint );
	}

}

- (void)rightMouseDown:(NSEvent *)theEvent
{

	if ( paint->readonly ) { return; }

	NonnonPaintPen_rightMouseDown( paint, theEvent );
	NonnonPaintGrabber_rightMouseDown( paint );

	[self.delegate NonnonPaintColorSet];

}


- (void)scrollWheel:(NSEvent *)theEvent
{

	// [!] : lower is faster response but not harder
	static u32 timer = 0;
	if ( n_posix_false == n_game_timer( &timer, 200 ) ) { return; }


	CGFloat delta = 0;

//NSLog( @"%f", [theEvent scrollingDeltaY] );
	if ( [theEvent scrollingDeltaY] == 0 )
	{
		//
	} else {
		if ( [theEvent scrollingDeltaY] < 0 )
		{
			delta = -1;
		} else {
			delta =  1;
		}
	}


	n_type_gfx p_zoom = paint->zoom;

	paint->zoom += delta;


	static int prev = 1;

	if ( ( paint->zoom == 0 )||( paint->zoom == -1 ) )
	{
		if ( prev > 0 ) { paint->zoom = -2; } else { paint->zoom = 1; }
	}

	if ( paint->zoom < -100 ) { paint->zoom = -100; } else
	if ( paint->zoom >  100 ) { paint->zoom =  100; }

	prev = paint->zoom;


	[self.delegate NonnonScrollbarZoomSync:TRUE];


	// [!] : Smart Zoom

	NSPoint pt = n_mac_cursor_position_get( self );

	n_type_gfx p_z = [self n_paint_zoom_get_int:     p_zoom];
	n_type_gfx c_z = [self n_paint_zoom_get_int:paint->zoom];

	if ( ( p_zoom > 0 )&&( paint->zoom > 0 ) )
	{

		paint->scroll.x = paint->scroll.x + pt.x;
		paint->scroll.x = paint->scroll.x / p_z;
		paint->scroll.x = paint->scroll.x * c_z;
		paint->scroll.x = paint->scroll.x - pt.x;

		paint->scroll.y = paint->scroll.y + pt.y;
		paint->scroll.y = paint->scroll.y / p_z;
		paint->scroll.y = paint->scroll.y * c_z;
		paint->scroll.y = paint->scroll.y - pt.y;
	} else {
		paint->scroll.x = paint->scroll.x + pt.x;
		paint->scroll.x = paint->scroll.x * p_z;
		paint->scroll.x = paint->scroll.x / c_z;
		paint->scroll.x = paint->scroll.x - pt.x;

		paint->scroll.y = paint->scroll.y + pt.y;
		paint->scroll.y = paint->scroll.y * p_z;
		paint->scroll.y = paint->scroll.y / c_z;
		paint->scroll.y = paint->scroll.y - pt.y;
	}


	[self.delegate NonnonPaintResize];

}




- (void) otherMouseUp:(NSEvent*) theEvent
{
//NSLog( @"otherMouseUp : %ld", (long) [theEvent buttonNumber] );

	if ( [theEvent buttonNumber] == 2 )
	{

		// [!] : middle button

		paint->cursor_grab_n_drag_onoff = FALSE;
		[self resetCursorRects];

	}

}

- (void) otherMouseDown:(NSEvent*) theEvent
{
//NSLog( @"otherMouseDown : %ld", (long) [theEvent buttonNumber] );

	// [!] : Grab N Drag

	if ( [theEvent buttonNumber] == 2 )
	{

		// [!] : middle button

		n_pt = [NSEvent mouseLocation];

		paint->cursor_grab_n_drag_onoff = TRUE;
		[self resetCursorRects];

	}

}

- (void) otherMouseDragged:(NSEvent*) theEvent
{
//NSLog( @"otherMouseDragged" );

	if ( [theEvent buttonNumber] == 2 )
	{

		// [!] : middle button

		CGPoint pt_cur = [NSEvent mouseLocation];

		CGFloat dx = n_pt.x - pt_cur.x;
		CGFloat dy = n_pt.y - pt_cur.y;
//NSLog( @"%f %f", dx, dy );

		n_pt = pt_cur;

		paint->scroll.x += dx;
		paint->scroll.y -= dy;


		paint->scroller_clamp = TRUE;

		[self display];

	}

}




- (BOOL)acceptsFirstResponder
{
//NSLog(@"acceptsFirstResponder");
	return YES;
}

- (BOOL)becomeFirstResponder
{
//NSLog(@"becomeFirstResponder");
        return YES;
}

- (void) keyDown : (NSEvent*) event
{
//NSLog( @"Key Code = %d", event.keyCode );

	switch( event.keyCode ) {

	case N_MAC_KEYCODE_ARROW_UP :

		if ( paint->tooltype != N_PAINT_TOOL_TYPE_GRABBER ) { break; }

		NonnonPaintGrabber_keyDown_arrow( paint, event.keyCode );

	break;

	case N_MAC_KEYCODE_ARROW_DOWN :

		if ( paint->tooltype != N_PAINT_TOOL_TYPE_GRABBER ) { break; }

		NonnonPaintGrabber_keyDown_arrow( paint, event.keyCode );

	break;

	case N_MAC_KEYCODE_ARROW_LEFT :

		if ( paint->tooltype != N_PAINT_TOOL_TYPE_GRABBER ) { break; }

		NonnonPaintGrabber_keyDown_arrow( paint, event.keyCode );

	break;

	case N_MAC_KEYCODE_ARROW_RIGHT:

		if ( paint->tooltype != N_PAINT_TOOL_TYPE_GRABBER ) { break; }

		NonnonPaintGrabber_keyDown_arrow( paint, event.keyCode );

	break;

	case N_MAC_KEYCODE_COPY: 

		if ( paint->tooltype != N_PAINT_TOOL_TYPE_GRABBER ) { break; }

		if ( event.modifierFlags & NSEventModifierFlagCommand )
		{
			if ( paint->grabber_mode == N_PAINT_GRABBER_DRAG_OK )
			{
				n_paint_grabber_copy();
			}
		}

	break;

	case N_MAC_KEYCODE_PASTE: 

		if ( paint->tooltype != N_PAINT_TOOL_TYPE_GRABBER ) { break; }

		if ( event.modifierFlags & NSEventModifierFlagCommand )
		{
			if ( paint->grabber_mode == N_PAINT_GRABBER_DRAG_OK )
			{
				n_paint_grabber_paste();
			}
		}

	break;

	case N_MAC_KEYCODE_SELECT_ALL:

		if ( paint->tooltype != N_PAINT_TOOL_TYPE_GRABBER ) { break; }

		if ( event.modifierFlags & NSEventModifierFlagCommand )
		{
			if ( paint->grabber_mode == N_PAINT_GRABBER_NEUTRAL )
			{
				n_paint_grabber_select_all();
			}
		}
	break;

	case N_MAC_KEYCODE_F2: 

		[self.delegate keyDown:event];

	break;

	case N_MAC_KEYCODE_NUMBER_1: 

		[self.delegate keyDown:event];

	break;

	case N_MAC_KEYCODE_UNDO:

		if ( paint->pen_quick_blur_onoff ) { break; }

		paint->pen_quick_eraser_onoff = TRUE;
		[self resetCursorRects];

	break;

	case N_MAC_KEYCODE_CUT:

		if ( paint->pen_quick_eraser_onoff ) { break; }

		paint->pen_quick_blur_onoff = TRUE;
		[self resetCursorRects];

	break;

	} // switch

}

- (void) keyUp : (NSEvent*) event
{

	switch( event.keyCode ) {

	case N_MAC_KEYCODE_UNDO:

		paint->pen_quick_eraser_onoff = FALSE;
		[self resetCursorRects];

	break;

	case N_MAC_KEYCODE_CUT:

		paint->pen_quick_blur_onoff = FALSE;
		[self resetCursorRects];

	break;

	} // switch

}




@end




#endif // _H_NONNON_MAC_NONNON_PAINT_CANVAS


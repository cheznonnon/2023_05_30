//
//  AppDelegate.h
//  Nonnon Paint for Mac
//
//  Created by のんのん on 2022/09/13.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end


//
//  AppDelegate.h
//  Pinknoise for Mac
//
//  Created by nonnon on 2022/07/05.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

